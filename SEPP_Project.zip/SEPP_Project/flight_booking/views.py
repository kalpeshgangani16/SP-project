from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
from .models import User, Flight, Booking
from .forms import LoginForm, ProfileUpdateForm, FlightSearchForm, BookingForm

def index(request):
    return render(request, 'index.html')

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(username=form.cleaned_data['username'],
                             password=form.cleaned_data['password'])
            if user and not user.account_locked:
                login(request, user)
                user.failed_login_attempts = 0
                user.save()
                return redirect('dashboard')
            else:
                if user:
                    user.failed_login_attempts += 1
                    if user.failed_login_attempts >= 3:
                        user.account_locked = True
                        user.locked_until = timezone.now() + timedelta(minutes=30)
                    user.save()
    return render(request, 'login.html', {'form': form})

@login_required
def profile_update(request):
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    return render(request, 'profile.html', {'form': form})

@login_required
def flight_search(request):
    if request.method == 'POST':
        form = FlightSearchForm(request.POST)
        if form.is_valid():
            flights = Flight.objects.filter(
                departure_city=form.cleaned_data['departure_city'],
                arrival_city=form.cleaned_data['arrival_city'],
                departure_time__date=form.cleaned_data['travel_date']
            )
            return render(request, 'flight_list.html', {'flights': flights})
    return render(request, 'search.html', {'form': form})

@login_required
def create_booking(request, flight_id):
    flight = Flight.objects.get(id=flight_id)
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid() and flight.available_seats > 0:
            booking = form.save(commit=False)
            booking.user = request.user
            booking.flight = flight
            booking.save()
            flight.available_seats -= 1
            flight.save()
            return redirect('booking_confirmation')
    return render(request, 'booking_form.html', {'form': form, 'flight': flight})
