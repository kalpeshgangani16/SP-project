from django import forms
from .models import User, Booking

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone_number', 'address', 'date_of_birth']

class FlightSearchForm(forms.Form):
    departure_city = forms.CharField()
    arrival_city = forms.CharField()
    travel_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    price_range = forms.ChoiceField(choices=[
        ('0-500', 'Under $500'),
        ('501-1000', '$501-$1000'),
        ('1001+', 'Over $1000')
    ], required=False)

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['seat_number']
