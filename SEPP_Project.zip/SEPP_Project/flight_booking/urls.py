from django.urls import path
from . import views

app_name = 'flight_booking'

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.login_view, name='login'),
    path('profile/', views.profile_update, name='profile'),
    path('search/', views.flight_search, name='search'),
    path('book/<int:flight_id>/', views.create_booking, name='create_booking'),
]
